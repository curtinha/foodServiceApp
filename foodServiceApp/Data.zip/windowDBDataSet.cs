﻿namespace foodServiceApp
{


    partial class windowDBDataSet
    {
    }
}
